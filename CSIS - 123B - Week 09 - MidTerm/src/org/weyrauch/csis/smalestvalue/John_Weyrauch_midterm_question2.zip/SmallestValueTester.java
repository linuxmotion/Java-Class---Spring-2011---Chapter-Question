package org.weyrauch.csis.smalestvalue;

public class SmallestValueTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		FindSmallestValue SMALLEST = new FindSmallestValue();
		SMALLEST.RunFindSmallestInteger();
		// TODO Auto-generated method stub

	}

}
