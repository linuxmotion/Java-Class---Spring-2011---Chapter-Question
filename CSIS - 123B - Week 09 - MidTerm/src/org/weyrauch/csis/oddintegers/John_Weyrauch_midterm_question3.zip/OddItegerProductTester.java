package org.weyrauch.csis.oddintegers;

public class OddItegerProductTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	 
	OddIntegerProduct mProduct = new OddIntegerProduct();
	mProduct.RunOddIntegerProgram();

	}

}
