package org.weyrauch.csis.binarydecimals;


/**
 * 
 * @author John Weyrauch
 * @teacher J. Huber
 * @version Midterm question 1
 * @class   CSIS - 123B - Spring 2011
 * @assignment Write an application that an integer containing
 *  only ones and zeros
 * @about Tester file for DecEqBin.java
 *  
 */
public class BinaryTester {

	public static void main(String[] args) {
		
		 DecEqBin DecimalProgram = new DecEqBin();
		 DecimalProgram.runDecEqBinProgram();

	}

}
